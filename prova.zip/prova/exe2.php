<?
    $num1=3;
    $num2=5;

    for($cont=1; $cont<$num1; $cont++){
        $soma= $cont+$num2;
         echo " " .$soma;
    }

?>